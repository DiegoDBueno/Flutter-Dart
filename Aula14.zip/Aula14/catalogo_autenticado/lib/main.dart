import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const baseUrl = String.fromEnvironment(
  'API_URL',
  defaultValue: 'http://10.0.2.2:8080',
);

void main() => runApp(
  const MaterialApp(debugShowCheckedModeBanner: false, home: CatalogoPage()),
);

class CatalogoPage extends StatefulWidget {
  const CatalogoPage({super.key});
  @override
  State<CatalogoPage> createState() => _CatalogoPageState();
}

class _CatalogoPageState extends State<CatalogoPage> {
  final usuario = TextEditingController(text: 'aluno');
  final senha = TextEditingController();
  String? token;
  List<Map<String, dynamic>> produtos = [];
  bool ocupado = false;
  String mensagem = '';

  @override
  void dispose() {
    usuario.dispose();
    senha.dispose();
    super.dispose();
  }

  Future<void> consultar() async {
    final resposta = await http
        .get(
          Uri.parse('$baseUrl/produtos'),
          headers: {'Authorization': 'Bearer $token'},
        )
        .timeout(const Duration(seconds: 10));
    if (resposta.statusCode == 401) {
      token = null;
      produtos = [];
      throw Exception('Sessão inválida. Entre novamente.');
    }
    if (resposta.statusCode != 200) {
      throw Exception('Consulta: HTTP ${resposta.statusCode}');
    }
    final dados = jsonDecode(utf8.decode(resposta.bodyBytes));
    if (dados is! List) throw const FormatException('Lista esperada');
    final novos = <Map<String, dynamic>>[];
    for (final item in dados) {
      if (item is! Map<String, dynamic> ||
          item['id'] is! String ||
          item['nome'] is! String ||
          item['preco'] is! num ||
          item['estoque'] is! int) {
        throw const FormatException('Produto fora do contrato');
      }
      novos.add(item);
    }
    produtos = novos;
  }

    Future<void> entrar() async {
    if (ocupado) return;
    if (usuario.text.trim().isEmpty || senha.text.isEmpty) {
      setState(() => mensagem = 'Preencha usuário e senha.');
      return;
    }
    setState(() { ocupado = true; mensagem = ''; produtos = []; });
    try {
      final resposta = await http.post(Uri.parse('$baseUrl/login'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'usuario': usuario.text.trim(), 'senha': senha.text}),
      ).timeout(const Duration(seconds: 10));
      if (resposta.statusCode != 200) {
        throw Exception('Login: HTTP ${resposta.statusCode}. Confira as credenciais.');
      }
      final dados = jsonDecode(utf8.decode(resposta.bodyBytes));
      if (dados is! Map<String, dynamic> ||
          dados['access_token'] is! String ||
          (dados['access_token'] as String).isEmpty) {
        throw const FormatException('Token ausente na resposta');
      }
      token = dados['access_token'] as String;
      senha.clear();
      await consultar();
    } catch (erro) {
      mensagem = erro.toString();
    } finally {
      if (mounted) setState(() => ocupado = false);
    }
  }

  Future<void> atualizar() async {
    if (ocupado || token == null) return;
    setState(() { ocupado = true; mensagem = ''; });
    try {
      await consultar();
    } catch (erro) {
      mensagem = erro.toString();
    } finally {
      if (mounted) setState(() => ocupado = false);
    }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Catálogo autenticado')),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        if (token == null) ...[
          TextField(controller: usuario,
            decoration: const InputDecoration(labelText: 'Usuário')),
          TextField(controller: senha, obscureText: true,
            decoration: const InputDecoration(labelText: 'Senha')),
          ElevatedButton(onPressed: ocupado ? null : entrar,
            child: const Text('Entrar')),
        ] else ...[
          ElevatedButton(onPressed: ocupado ? null : atualizar,
            child: const Text('Atualizar')),
          TextButton(onPressed: ocupado ? null : () => setState(() {
            token = null; produtos = []; mensagem = '';
          }), child: const Text('Sair')),
        ],
        if (ocupado) const LinearProgressIndicator(),
        if (mensagem.isNotEmpty) Text(mensagem),
        if (!ocupado && token != null && mensagem.isEmpty && produtos.isEmpty)
          const Text('Nenhum produto cadastrado.'),
        if (mensagem.isEmpty)
          for (final produto in produtos)
            Card(child: ListTile(
              title: Text(produto['nome'] as String),
              subtitle: Text('R\$ ${(produto['preco'] as num).toStringAsFixed(2)}'
                ' · Estoque: ${produto['estoque']}'),
            )),
      ]),
    );
  }