package com.example.catalogo_autenticado

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
