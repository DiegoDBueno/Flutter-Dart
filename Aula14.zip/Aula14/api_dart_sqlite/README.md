# Aula 14 — material vigente em 10/11/2026

API em api_dart/; pacote api_dart_sqlite.zip. Aplicativo em flutter/main.dart e versões incrementais em flutter/etapas/. Aula em ../../aulas/aula14.html e PDF em ../pdfs/aula14.pdf.

Na pasta api_dart: dart pub get e dart run bin/servidor.dart. Navegador: http://localhost:8080/docs. Conta fictícia: aluno / 123456. Consulte POST /login; cole somente access_token em Authorize; execute GET /produtos.

No app Flutter novo, adicionar http e usar main.dart. Iniciar com --dart-define=API_URL=http://10.0.2.2:8080 no emulador ou http://localhost:8080 no Web do PC. O aplicativo faz login próprio.

Swagger UI 5.30.2 está incluído em api_dart/public; licença em SWAGGER-LICENSE. Requer Dart >=3.7 <4, navegador e pasta gravável. Primeiro pub get depende de rede; uso offline depende do cache preparado no PC. Windows usa winsqlite3.dll via sqlite3 2.9.4.

catalogo-api/ e api_java_sqlite.zip são arquivos históricos, preservados; não são usados nesta versão. Não há dependência de Java/Maven/Node no percurso atual. Não usar contas reais nem publicar este exemplo HTTP como serviço de produção.
